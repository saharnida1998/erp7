﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp3
{
    public partial class Form3 : Form
    {

        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the '_ERP_Swm_DataSet.Buyer_Purchase_DB' table. You can move, or remove it, as needed.
            //this.buyer_Purchase_DBTableAdapter.Fill(this._ERP_Swm_DataSet.Buyer_Purchase_DB);
            {
                SqlConnection con = new SqlConnection(@"Data source =DESKTOP-1JEPHKI;Integrated Security=True");

                string query = "select garbage_type from w_stats_sale where availibility='yes'";
                con.Open();
                SqlCommand cmd = new SqlCommand(query, con);
                SqlDataReader rd = cmd.ExecuteReader();
                while (rd.Read())
                {

                    comboBox1.Items.Add(rd.GetString(0));
                }

            }

           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data source =DESKTOP-1JEPHKI;Integrated Security=True");
            SqlCommand cmd;
            con.Open();
            cmd = new SqlCommand("insert into soldout(Buyer_name,phoneno,address,pakage_type,price,date) values('" + textBox1.Text + "','" + textBox1.Text + "', '" + textBox3.Text + "','" + comboBox1.Text + "','" + textBox5.Text + "','" + dateTimePicker1.Value + "')", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("data inserted");
            con.Close();

          
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}
