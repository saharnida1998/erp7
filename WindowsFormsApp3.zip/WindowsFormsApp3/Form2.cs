﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp3
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'masterDataSet.incoming_wm' table. You can move, or remove it, as needed.
            this.incoming_wmTableAdapter.Fill(this.masterDataSet.incoming_wm);
            SqlConnection Conn = new SqlConnection(@"Data source =DESKTOP-1JEPHKI;Integrated Security=True");
            SqlCommand Comm1 = new SqlCommand("select count(id) from user_booking", Conn);
            Conn.Open();
            SqlDataReader DR1 = Comm1.ExecuteReader();
            if (DR1.Read())
            {


                bunifuMaterialTextbox1.Text = DR1.GetValue(0).ToString();
            }

            Conn.Close();
            SqlConnection Conn1 = new SqlConnection(@"Data source =DESKTOP-1JEPHKI;Integrated Security=True");
            SqlCommand Comm2 = new SqlCommand("select count(status) from employee_reg", Conn1);
            Conn1.Open();
            SqlDataReader DR2 = Comm2.ExecuteReader();
            if (DR2.Read())
            {


                bunifuMaterialTextbox2.Text = DR2.GetValue(0).ToString();
            }

            Conn1.Close();
            
            SqlConnection Conn2 = new SqlConnection(@"Data source =DESKTOP-1JEPHKI;Integrated Security=True");
            SqlCommand Comm3 = new SqlCommand("select count(id) from user_booking", Conn2);
            Conn2.Open();
            SqlDataReader DR3 = Comm3.ExecuteReader();
            if (DR3.Read())
            {


                bunifuMaterialTextbox3.Text = DR3.GetValue(0).ToString();
            }

            Conn2.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
           
        }

        private void button6_Click(object sender, EventArgs e)
        {
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            EmployeInfo emp = new EmployeInfo();
            emp.Show();
        }

       

        private void button9_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Booking bk = new Booking();
            bk.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Warehouse stg = new Warehouse();
            stg.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {

            Booking bk = new Booking();
            bk.Show();
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {

            EmployeInfo emp = new EmployeInfo();
            emp.Show();
        }

        private void bunifuFlatButton4_Click(object sender, EventArgs e)
        {

            Warehouse stg = new Warehouse();
            stg.Show();
        }

        private void bunifuFlatButton5_Click(object sender, EventArgs e)
        {
            About ab = new About();
            ab.Show();


        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton6_Click(object sender, EventArgs e)
        {
            Finance fc = new Finance();
            fc.Show();
        }

        private void bunifuFlatButton9_Click(object sender, EventArgs e)
        {
            EmployeInfo emp = new EmployeInfo();
            emp.Show();
        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton3_Click_1(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.Show();
        }

        private void bunifuFlatButton7_Click(object sender, EventArgs e)
        {

        }
    }
}
