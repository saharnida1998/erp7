﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp3
{
    public partial class Warehouse : Form
    {
       
        public Warehouse()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void bunifuFlatButton5_Click(object sender, EventArgs e)
        {
           
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
           

        }

        private void Warehouse_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'masterDataSet2.w_stats_sale' table. You can move, or remove it, as needed.
            this.w_stats_saleTableAdapter.Fill(this.masterDataSet2.w_stats_sale);
            // TODO: This line of code loads data into the 'masterDataSet1.w_stats_dump' table. You can move, or remove it, as needed.
            this.w_stats_dumpTableAdapter.Fill(this.masterDataSet1.w_stats_dump);


        }
    }
}
