﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using FireSharp.Config;
using FireSharp.Response;
using FireSharp.Interfaces;
using FireSharp;
using Newtonsoft.Json;


namespace WindowsFormsApp3
{
    public partial class EmployeInfo : Form
    {
       // SqlConnection con = new SqlConnection(@"Data source =DESKTOP-1JEPHKI;Integrated Security=True");
        //SqlCommand cmd;
       // SqlDataAdapter adapt;
      // DataSet ds;
        //SqlCommandBuilder cmdbl;
        public EmployeInfo()
        {
            InitializeComponent();
        }
        IFirebaseConfig ifc = new FirebaseConfig()
        {
            AuthSecret = "jYWizlFBx5wCes58o8aLvY4gUCwrIOakgah7vJzw",
            BasePath= "https://android-47119-default-rtdb.firebaseio.com/"
        };
        IFirebaseClient client;
        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            
            
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            
        }

        private void bunifuFlatButton5_Click(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void EmployeInfo_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'erpdbDataSet.table_name' table. You can move, or remove it, as needed.
           // this.table_nameTableAdapter.Fill(this.erpdbDataSet.table_name);
            try
            {
                client = new FirebaseClient(ifc);
            }
            catch
            {

                MessageBox.Show("There is problem in Your Internet");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FirebaseResponse res = client.Get(@"Employee");
            Dictionary<string, Employee> data = JsonConvert.DeserializeObject<Dictionary<string, Employee>>(res.Body.ToString());
            populatertb(data);
        }

        private void button3_Click(object sender, EventArgs e)
        {
           
            
        }
        void populatertb(Dictionary<string,Employee>record)
        {
            richTextBox1.Clear();
            foreach (var item in record)
            {
                richTextBox1.Text += item.Key + "\n\n";
                richTextBox1.Text += "Date: "+item.Value.date + "\n";
                richTextBox1.Text += "Designation: "+item.Value.designation + "\n";
                richTextBox1.Text += "Email: "+item.Value.email + "\n";
                richTextBox1.Text += "Fullaname: "+item.Value.fullname + "\n";
                richTextBox1.Text += "Gender: " + item.Value.gender + "\n";
                richTextBox1.Text += "Password: " + item.Value.password + "\n";
                richTextBox1.Text += "Phone No: " + item.Value.phoneNo + "\n";
                richTextBox1.Text += "Username: " + item.Value.username + "\n";
                richTextBox1.Text += "V. license No: " + item.Value.vlicenseNo + "\n";
                richTextBox1.Text += "V. Model No: " + item.Value.vmodelno + "\n";
                richTextBox1.Text += "V. Number: " + item.Value.vnumder + "\n";
                richTextBox1.Text += "V. Owner Name: " + item.Value.vownername + "\n";
            }
            
        }
        
            
        

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data source =DESKTOP-1JEPHKI;Integrated Security=True");
                SqlCommand cmd;
                con.Open();
                cmd = new SqlCommand("insert into employee_reg(registration,status,reg_no,salary) values('" + textBox13.Text + "','" + bunifuDropdown1.selectedValue + "','" + textBox1.Text + "','" + comboBox1.Text + "')", con);
                cmd.ExecuteNonQuery();
                MessageBox.Show("data inserted");
                con.Close();
            }
            catch (Exception)
            {

                MessageBox.Show("There is no data to Insert,Add data first");
            }
            



        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(richTextBox1.SelectedText);
            }
            catch (Exception)
            {

                MessageBox.Show("there is no text to copy, retrive first");
            }
        }

        private void button2_Click_2(object sender, EventArgs e)
        {
            try
            {
                textBox13.Text = Clipboard.GetText();
            }
            catch (Exception)
            {

                MessageBox.Show("copy firsth, then paste here");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            
                }

        private void bunifuDropdown1_onItemSelected(object sender, EventArgs e)
        {
            if(bunifuDropdown1.selectedIndex==0)
            {
                comboBox1.Enabled = true;
                textBox1.ReadOnly = false;
            }
            else if(bunifuDropdown1.selectedIndex == 1)
            {
                comboBox1.Enabled = false;
                textBox1.ReadOnly = true;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
