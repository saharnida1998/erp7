﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using FireSharp.Config;
using FireSharp.Response;
using FireSharp.Interfaces;
using FireSharp;
using Newtonsoft.Json;

namespace WindowsFormsApp3
{





    public partial class Booking : Form
    {
        SqlConnection cnn = new SqlConnection(@"Data Source=DESKTOP-1JEPHKI;Integrated Security=True;");
        // SqlCommand cmd;
        public Booking()
        {
            InitializeComponent();
        }
        IFirebaseConfig ifc = new FirebaseConfig()
        {
            AuthSecret = "jYWizlFBx5wCes58o8aLvY4gUCwrIOakgah7vJzw",
            BasePath = "https://android-47119-default-rtdb.firebaseio.com/"
        };
        IFirebaseClient client;

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        private void Booking_Load(object sender, EventArgs e)
        {
            
            try
            {
                client = new FirebaseClient(ifc);
            }
            catch
            {

                MessageBox.Show("There is problem in Your Internet");
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            Booking bk = new Booking();
            bk.Show();

        }

        private void bunifuFlatButton5_Click(object sender, EventArgs e)
        {
            
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FirebaseResponse res = client.Get(@"BookPickup");
            Dictionary<string, BookPickup> data = JsonConvert.DeserializeObject<Dictionary<string, BookPickup>>(res.Body.ToString());
            populatertb(data);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(richTextBox1.SelectedText);
            }
            catch (Exception)
            {

                MessageBox.Show("there is no text to copy, retrive first");
            }
            
                
            
            
            
        }
        void populatertb(Dictionary<string, BookPickup> record)
        {
            richTextBox1.Clear();
            foreach (var item in record)
            {
                richTextBox1.Text += item.Key + "\n\n";
                richTextBox1.Text += "dateAndTime " + item.Value.dateAndTime + "\n";
                richTextBox1.Text += " latitude: " + item.Value.latitude + "\n";
                richTextBox1.Text += " logitude: " + item.Value.longitude + "\n";
                richTextBox1.Text += " materialWeight: " + item.Value.materialWeight + "\n";
                richTextBox1.Text += " pakageType: " + item.Value.pakageType + "\n";
                richTextBox1.Text += " phoneNo: " + item.Value.phoneNo + "\n";
                richTextBox1.Text += " pickupAdress: " + item.Value.pickupAdress + "\n";
                richTextBox1.Text += " requestedID: " + item.Value.requestedID + "\n";

            }
           
        }
        class BookPickup
        {
            public string dateAndTime { get; set; }
            public string latitude { get; set; }
            public string longitude { get; set; }
            public string materialWeight { get; set; }
            public string pakageType { get; set; }
            public string phoneNo { get; set; }
            public string pickupAdress { get; set; }
            public string requestedID { get; set; }

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data source =DESKTOP-1JEPHKI;Integrated Security=True");
            SqlCommand cmd;
            con.Open();
            cmd = new SqlCommand("insert into user_booking(profile_info,pakage_type,classification,garbage_type,garbage,price,picker_regno) values('" + textBox1.Text + "','" + bunifuDropdown1.selectedValue + "', '" + comboBox1.Text + "','" + comboBox3.Text + "','" + comboBox2.Text + "','" + textBox2.Text + "','" + comboBox4.Text + "')", con);
            cmd.ExecuteNonQuery();
            MessageBox.Show("data inserted");
            con.Close();
        }

        private void bunifuDropdown2_onItemSelected(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                textBox1.Text = Clipboard.GetText();
            }
            catch (Exception)
            {

                MessageBox.Show("copy firsth, then paste here");
            }
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            FirebaseResponse res = client.Get(@"schedulePickup");
            Dictionary<string, schedulePickup> data = JsonConvert.DeserializeObject<Dictionary<string, schedulePickup>>(res.Body.ToString());
            populatertb1(data);
        }
        void populatertb1(Dictionary<string, schedulePickup> record)
        {
            richTextBox1.Clear();
            foreach (var item in record)
            {
                richTextBox1.Text += item.Key + "\n\n";
                richTextBox1.Text += " endDate_input " + item.Value.endDate_input + "\n";
                richTextBox1.Text += " materialType_drop_downtext: " + item.Value.materialType_drop_downtext + "\n";
                richTextBox1.Text += " materialWeight: " + item.Value.materialWeight + "\n";
                richTextBox1.Text += " pakageType: " + item.Value.pakageType + "\n";
                richTextBox1.Text += " pickup_input: " + item.Value.pickup_input + "\n";
                richTextBox1.Text += " startDate_input: " + item.Value.startDate_input + "\n";


            }
        }
            class schedulePickup
        {
            public string endDate_input { get; set; }
            public string materialType_drop_downtext { get; set; }
            public string materialWeight { get; set; }
            public string pakageType { get; set; }
            public string pickup_input { get; set; }
            public string startDate_input { get; set; }

        }

        private void bunifuDropdown3_onItemSelected(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0) 
            {
                comboBox2.Items.Clear();
                comboBox3.Items.Clear();
                comboBox2.Items.AddRange(new object[] {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31 });
                comboBox3.Items.AddRange(new object[] { "Plastic Waste", "Paper Waste", "Metal Waste", "Glass Waste", "Food Waste", "Chemical Waste", "Electrical Waste", "Construction Waste" });
            }
            else if(comboBox1.SelectedIndex == 1)
            {
                comboBox2.Items.Clear();
                comboBox3.Items.Clear();
                comboBox2.Items.AddRange(new object[] { 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20 });
                comboBox3.Items.AddRange(new object[] { "House Hold", " Community", "Hospital", "Institute", "Public", "Meat House Waste", "Islamic Content Residue", "Factory Waste" });
            }
            
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex == 0 || comboBox2.SelectedIndex == 1 || comboBox2.SelectedIndex == 2 || comboBox2.SelectedIndex == 3|| comboBox2.SelectedIndex == 4 )
            {
                textBox2.Clear();
                textBox2.Text = "50";
            }
            else if (comboBox2.SelectedIndex == 5 || comboBox2.SelectedIndex == 6 || comboBox2.SelectedIndex == 7 || comboBox2.SelectedIndex == 8 || comboBox2.SelectedIndex == 9)
            {
                textBox2.Clear();
                textBox2.Text = "100";
            }
            else if (comboBox2.SelectedIndex == 10 || comboBox2.SelectedIndex == 11 || comboBox2.SelectedIndex == 12 || comboBox2.SelectedIndex == 13 || comboBox2.SelectedIndex == 14)
            {
                textBox2.Clear();
                textBox2.Text = "150";
            }
            else if (comboBox2.SelectedIndex == 15 || comboBox2.SelectedIndex == 16 || comboBox2.SelectedIndex == 17 || comboBox2.SelectedIndex == 18 || comboBox2.SelectedIndex == 19)
            {
                textBox2.Clear();
                textBox2.Text = "200";
            }
            else if (comboBox2.SelectedIndex == 20 || comboBox2.SelectedIndex == 21 || comboBox2.SelectedIndex == 22 || comboBox2.SelectedIndex == 23 || comboBox2.SelectedIndex == 24)
            {
                textBox2.Clear();
                textBox2.Text = "250";
            }
            else if (comboBox2.SelectedIndex == 25 || comboBox2.SelectedIndex == 26 || comboBox2.SelectedIndex == 27 || comboBox2.SelectedIndex == 28 || comboBox2.SelectedIndex == 29)
            {
                textBox2.Clear();
                textBox2.Text = "300";
            }
        }

        private void bunifuDropdown1_onItemSelected(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data source =DESKTOP-1JEPHKI;Integrated Security=True");
            
            string query = "select reg_no from employee_reg where status='approved'";
            con.Open();
            SqlCommand cmd = new SqlCommand(query,con);
            SqlDataReader rd = cmd.ExecuteReader();
            while(rd.Read())
            {
               
                comboBox4.Items.Add(rd.GetString(0));
            }
            
            //con.Close();
            

        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

