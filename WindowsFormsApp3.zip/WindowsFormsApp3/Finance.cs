﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp3
{
    public partial class Finance : Form
    {
        public Finance()
        {
            InitializeComponent();
        }

        private void Finance_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'masterDataSet4.user_booking' table. You can move, or remove it, as needed.
            this.user_bookingTableAdapter.Fill(this.masterDataSet4.user_booking);
            // TODO: This line of code loads data into the 'masterDataSet3.employee_reg' table. You can move, or remove it, as needed.
            this.employee_regTableAdapter.Fill(this.masterDataSet3.employee_reg);
            

            SqlConnection Conn = new SqlConnection(@"Data source =DESKTOP-1JEPHKI;Integrated Security=True");
            SqlCommand Comm1 = new SqlCommand("select sum(price) from user_booking", Conn);
            Conn.Open();
            SqlDataReader DR1 = Comm1.ExecuteReader();
            if (DR1.Read())
            {


                bunifuMaterialTextbox1.Text = DR1.GetValue(0).ToString();
            }
            
            Conn.Close();
            SqlCommand Comm2 = new SqlCommand("select sum(salary) from employee_reg", Conn);
            Conn.Open();
            SqlDataReader DR2 = Comm2.ExecuteReader();
            if (DR2.Read())
            {


                bunifuMaterialTextbox2.Text = DR2.GetValue(0).ToString();
            }

            Conn.Close();
            int a = Convert.ToInt32(bunifuMaterialTextbox1.Text);
            int b = Convert.ToInt32(bunifuMaterialTextbox2.Text);
            int c = a - b;
            bunifuMaterialTextbox3.Text = Convert.ToString(c);

            /* SqlConnection con = new SqlConnection(@"Data source =DESKTOP-1JEPHKI;Integrated Security=True");
             SqlCommand cmd;
             SqlDataAdapter da = new SqlDataAdapter();
             con.Open();
             cmd = new SqlCommand("select sum(price) from user_booking)", con);
             cmd.Parameters.Add(new SqlParameter("@price", "%" + bunifuMaterialTextbox1 + "%"));
             /* values('" +int.Parse(bunifuMaterialTextbox1.Text) +"')"
             SqlDataReader rd = cmd.ExecuteReader();
             cmd.ExecuteNonQuery();
            while(rd.Read())
             {

             }

             con.Close();*/

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton5_Click(object sender, EventArgs e)
        {

        }
    }
}
